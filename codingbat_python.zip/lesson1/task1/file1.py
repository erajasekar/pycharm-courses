def sum_double(a, b):
    insert your code here